function updateClock(){

const now = new Date();

document.getElementById("time").textContent =
now.toLocaleTimeString([],{
hour:'2-digit',
minute:'2-digit',
second:'2-digit'
});

document.getElementById("date").textContent =
now.toDateString();
}

setInterval(updateClock,1000);
updateClock();

const hour = new Date().getHours();

const greeting = document.getElementById("greeting");

if(hour < 12){
greeting.textContent = "☀️ Good Morning";
}
else if(hour < 18){
greeting.textContent = "🌤️ Good Afternoon";
}
else{
greeting.textContent = "🌙 Good Evening";
}

function searchWeb(){

const query =
document.getElementById("searchInput").value;

const engine =
document.getElementById("engine").value;

let url = "";

if(engine==="google"){
url="https://www.google.com/search?q="+encodeURIComponent(query);
}
else if(engine==="duckduckgo"){
url="https://duckduckgo.com/?q="+encodeURIComponent(query);
}
else{
url="https://www.youtube.com/results?search_query="+encodeURIComponent(query);
}

window.open(url,"_blank");
}

document.getElementById("searchBtn")
.addEventListener("click",searchWeb);

document.getElementById("searchInput")
.addEventListener("keydown",function(e){
if(e.key==="Enter"){
searchWeb();
}
});

const quotes = [
"Stay hungry. Stay foolish.",
"Success is the sum of small efforts.",
"Dream big and dare to fail.",
"Every day is a second chance.",
"Make today amazing.",
"Focus on progress, not perfection."
];

document.getElementById("quote").textContent =
quotes[Math.floor(Math.random()*quotes.length)];

const notes = document.getElementById("notes");

notes.value =
localStorage.getItem("dashboardNotes") || "";

notes.addEventListener("input",()=>{
localStorage.setItem("dashboardNotes",notes.value);
});

const themeBtn =
document.getElementById("themeToggle");

if(localStorage.getItem("theme")==="light"){
document.body.classList.add("light-theme");
themeBtn.textContent="☀️";
}

themeBtn.addEventListener("click",()=>{

document.body.classList.toggle("light-theme");

if(document.body.classList.contains("light-theme")){
localStorage.setItem("theme","light");
themeBtn.textContent="☀️";
}
else{
localStorage.setItem("theme","dark");
themeBtn.textContent="🌙";
}

});